package com.springboot.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.bean.Multibank;

@RestController
public class MultibankController {
	@GetMapping("/hello")
	public String getHello() {
		return "Hello Spring Boot!";
	}

	@GetMapping("/multibank")
	public ResponseEntity<Multibank> getMultibank() {
		Multibank m1 = new Multibank();
		m1.setId("1234");
		m1.setFullname("Kraipob Saengkhunthod");
		m1.setAge("20");

		// Multibank m2 = new Multibank();
		// m2.setId("1234");
		// m2.setFullname("Kraipob Saengkhunthod");
		// m2.setAge("20");
		return new ResponseEntity<>(m1, HttpStatus.OK);

	}
}